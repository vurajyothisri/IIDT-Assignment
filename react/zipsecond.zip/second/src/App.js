
import './App.css';
import Main from './component/main';
function App() {
  return (
  <Main />
  );
}

export default App;
